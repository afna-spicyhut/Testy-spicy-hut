(function () {
  emailjs.init("rhTFOXkV5d-VBH-c9"); // Public Key
})();

document.getElementById("contact-form").addEventListener("submit", function (e) {
  e.preventDefault();

  emailjs.sendForm(
    "service_nu5sk63",   // Service ID
    "template_vs5gxv5",  // Template ID
    this
  ).then(
    function () {
      alert("Message sent successfully!");
    },
    function (error) {
      alert("Failed to send message");
    }
  );
});